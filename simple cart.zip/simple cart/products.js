// DUMMY PRODUCTS (PRODUCT ID : DATA)
var products = {
  123: {
    name : "Small pizza",
    desc : "njoy your fave pizza, your way. Customise your pizza base! You can Double-Stack® it, get a Crammed-Crust®, make it Thin & Crispy or choose SlimFit for a healthier option.",
    img : "pizza.jpg",
    price : 59,
  },
  124: {
    name : "Medium pizza",
    desc : "Mzansi’s fave pizza, the Triple-Decker®, comes in three amazing flavours: Creamy Chicken, Sweet Chilli Chicken, and Meaty.",
    img : "pizza.jpg",
    price : 99,
  },
  125: {
    name : "Large pizza ",
    desc : "Enjoy our delicious and spicy Sweet Chilli Chicken pizza,comes in three amazing flavours: Creamy Chicken",
    img : "pizza.jpg",
    price : 169,
  },
  
  126: {
    name : "Famaly combo 3X pizza ",
    desc : "Enjoy with your family the 3X combo of our delicious and spicy Sweet Chilli Chicken pizza,comes in three amazing flavours: Creamy Chicken",
    img : "pizza.jpg",
    price : 209,
  },

};